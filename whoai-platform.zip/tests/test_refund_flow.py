from httpx import AsyncClient, ASGITransport
import pytest

from main import app


@pytest.mark.anyio
async def test_health():
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test"
    ) as client:

        response = await client.get("/health")

        assert response.status_code == 200
        assert response.json()["status"] == "ok"