// 1.5 Permission Check
if (actionContext.targetResource) {
  const hasPermission = agent.permissions.some(p =>
    p.resource === actionContext.targetResource &&
    p.action === actionContext.type
  );

  if (!hasPermission) {
    return {
      allowed: false,
      reason: `INSUFFICIENT_PERMISSIONS: ${actionContext.targetResource}:${actionContext.type}`
    };
  }
}